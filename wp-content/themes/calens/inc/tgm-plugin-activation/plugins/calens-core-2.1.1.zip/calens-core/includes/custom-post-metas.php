<?php
/**
 * Custom post type fields
 *
 * @package Calens Core
 */
include trailingslashit( CALENSCORE_PATH ) . 'includes/custom-post-metas/team.php';
include trailingslashit( CALENSCORE_PATH ) . 'includes/custom-post-metas/project.php';
include trailingslashit( CALENSCORE_PATH ) . 'includes/custom-post-metas/testimonial.php';
include trailingslashit( CALENSCORE_PATH ) . 'includes/custom-post-metas/page.php';
include trailingslashit( CALENSCORE_PATH ) . 'includes/custom-post-metas/service.php';

